package com.statista.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SearchResultsPage {
	private WebDriver driver;
	public SearchResultsPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	//top menu drop downs section
	
	//prices
	@FindBy(xpath="//*[@class='navMain__navigationItem'][contains(text(),'Prices')]")
	public WebElement pricesDropDownMenu;
	@FindBy(xpath="//*[@class='navMain__navigationItem'][contains(text(),'Prices')]")
	public WebElement pricesDropDownArrow;

	//big search box
	@FindBy(id="q")
	public WebElement mainSearchBox;
	//search button for main search box
	@FindBy(className="fa-search fa")
	public WebElement mainSearchBoxButton;
	//search results return links containing string method
	public WebElement searchResultsLinks(String linkContaingText) {
		return driver.findElement(By.xpath("//h2[contains(text(),'"+linkContaingText+"')]"));
	}
	//sort by select box
	@FindBy(xpath="//select[@id='sortMethod']")
	public WebElement sortSelectBox;
	public void sortBySelectBox(String s) {
		Select select = new Select(sortSelectBox);
		select.selectByValue(s);
	}
	//location focus select box
	@FindBy(xpath="//select[@id='isRegionPref']")
	public WebElement locationFocusSelectBox;
	public void locationFocusSelectBox(String s) {
		Select select = new Select(locationFocusSelectBox);
		select.selectByValue(s);
	}
	//statistics section
	@FindBy(xpath="//input[@id='statistics']")
	public WebElement statisticsCheckbox;
	@FindBy(xpath="//input[@id='forecasts']")
	public WebElement forcastCheckbox;
	@FindBy(xpath="//input[@id='infos']")
	public WebElement infographicsCheckbox;
	@FindBy(xpath="//input[@id='topics']")
	public WebElement topicsCheckbox;
	//studies & reports
	@FindBy(xpath="//input[@id='dossiers']")
	public WebElement dossiersCheckbox;
	@FindBy(xpath="//input[@id='groupA']")
	public WebElement statistaCheckbox;
	@FindBy(xpath="//input[@id='groupB']")
	public WebElement industryCheckbox;
	@FindBy(xpath="//input[@id='groupC']")
	public WebElement additionalCheckbox;
	//expert tools section
	@FindBy(xpath="//input[@id='dmo']")
	public WebElement digitalCheckbox;
	@FindBy(xpath="//input[@id='cmo']")
	public WebElement consumerCheckbox;
	@FindBy(xpath="//input[@id='companies']")
	public WebElement companiesCheckbox;
	//search accuracy section
	@FindBy(xpath="//input[@id='accuracy_0']")
	public WebElement wideAccuracyCheckbox;
	@FindBy(xpath="//input[@id='accuracy_1']")
	public WebElement normalAccuracyCheckbox;
	@FindBy(xpath="//input[@id='accuracy_2']")
	public WebElement highAccuracyCheckbox;
	// regions check box
	@FindBy(xpath="//select[@id='isoregion']")
	public WebElement regionsSelectBox;
	public void selectFromRegionsSelectBox(String s) {
		Select select = new Select(regionsSelectBox);
		select.selectByValue(s);
	}
	//country search and select section
	@FindBy(xpath="//input[@id='isocountrySearch']")
	public WebElement countrySearchBox;
	@FindBy(xpath="//input[@id='isocountry_4']")
	public WebElement afghanistanCheckbox;
	@FindBy(xpath="//input[@id='isocountry_8']")
	public WebElement albaniaCheckbox; 	
	@FindBy(xpath="//input[@id='isocountry_12']")
	public WebElement algeriaCheckbox; 	
	@FindBy(xpath="//input[@id='isocountry_20']")
	public WebElement andorraCheckbox; 	
	@FindBy(xpath="//input[@id='isocountry_24']")
	public WebElement angolaCheckbox; 	
	@FindBy(xpath="//input[@id='isocountry_28']")
	public WebElement antiguaBarbudaCheckbox; 	
 	
	//industry select box
	@FindBy(xpath="//select[@id='category']")
	public WebElement industrySelectBox;
	public void industrySelectBox(String s) {
		Select select = new Select(industrySelectBox);
		select.selectByValue(s);
	}
	//publication date select box
	@FindBy(xpath="//select[@id='interval']")
	public WebElement  publicationDateSelectBox;
	public void publicationDateSelectBox(String s) {
		Select select = new Select(publicationDateSelectBox);
		select.selectByValue(s);
	}
	//archive select box
	@FindBy(xpath="//select[@id='archive']")
	public WebElement  archiveSelectBox;
	public void archiveSelectBox(String s) {
		Select select = new Select(archiveSelectBox);
		select.selectByValue(s);
	}
	//RESET ALL FILTERS
	@FindBy(id="js-reset-all-filters")
	public WebElement  resetAllFiltersButton;
	
	//go to page number web elements method
	public WebElement getGoToPageNumberElement(String pageNumber) {
		return driver.findElement(By.xpath("//a[@class='pagination__link'][contains(text(),'"+pageNumber+"')]"));
	}
	@FindBy(xpath="//h4[@class='hl-module hideMobile']")
	public WebElement resultsCountLabel;
	
	
}
